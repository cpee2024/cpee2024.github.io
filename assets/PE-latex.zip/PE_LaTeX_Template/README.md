pe.sty
======
Latex style for journal Przeglad Elektrotechniczny.  
Oldest magazine of Polish electrician. It appears since 1919.   
http://www.pe.org.pl/

ISSN 0033-2097  
Editor-in-Chief : prof. Sławomir TUMANSKI  
e-mail:tusla@iem.pw.edu.pl

Sources of latex template available at:  
https://github.com/sawickib/pe.sty
